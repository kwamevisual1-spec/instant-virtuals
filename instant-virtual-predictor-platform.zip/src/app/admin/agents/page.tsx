import { redirect } from "next/navigation";
import { getCurrentUser, getUserByToken, getUserSessionToken } from "@/lib/auth";
import { AgentManagement } from "./AgentManagement";

export const dynamic = "force-dynamic";
export const metadata = { title: "Agent Management — Virtuals Pro" };

export default async function Page({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const { t } = await searchParams;
  const user = (await getUserByToken(t)) || (await getCurrentUser());
  if (!user) redirect("/signin");
  if (!user.isAdmin) redirect("/dashboard");
  const token = (await getUserSessionToken(user)) || t || "";
  return <AgentManagement token={token} />;
}
