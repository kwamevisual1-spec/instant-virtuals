import { redirect } from "next/navigation";
import { getCurrentUser, getUserByToken } from "@/lib/auth";
import { AdminPanel } from "./AdminPanel";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";
import {
  isSupabaseConfigured,
  getRequestSupabase,
  getSupabaseAccessToken,
  getSupabaseUrl,
  getSupabaseAnonKey,
} from "@/lib/supabase";
import type { SupabaseClient } from "@supabase/supabase-js";

export const metadata = { title: "Admin — Virtuals Pro" };
export const dynamic = "force-dynamic";

type RegRow = {
  id: number;
  userId: string;
  amount: string;
  currency: string;
  network: string;
  transactionReference: string | null;
  screenshotName: string | null;
  screenshotData: string | null;
  screenshotUrl: string | null;
  createdAt: string;
  status: string;
  userName: string | null;
  userEmail: string | null;
  userPhone: string | null;
  userCountry: string | null;
  userCountryFlag: string | null;
  userRegistrationStatus: string | null;
};

type PlanRow = {
  id: number;
  userId: string;
  amount: string;
  currency: string;
  planCode: string | null;
  planName: string | null;
  network: string;
  transactionReference: string | null;
  screenshotName: string | null;
  screenshotData: string | null;
  screenshotUrl: string | null;
  createdAt: string;
  status: string;
  userName: string | null;
  userEmail: string | null;
  userPhone: string | null;
  userActivePlan: string | null;
  userPendingPlan: string | null;
};

type UserRow = {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  registrationStatus: string;
  activePlan: string;
  planStatus: string;
  pendingPlan: string | null;
  createdAt: string;
};

async function fetchSupabaseAdminData(svc: SupabaseClient) {
  // `svc` is signed in as the admin (cookie or ?t= token); admin RLS policies apply
  const [regsRes, plansRes, usersRes] = await Promise.all([
    svc
      .from("payments")
      .select("*")
      .eq("payment_type", "registration")
      .eq("status", "pending")
      .order("created_at", { ascending: false })
      .limit(50),
    svc
      .from("payments")
      .select("*")
      .eq("payment_type", "plan")
      .eq("status", "pending")
      .order("created_at", { ascending: false })
      .limit(50),
    svc
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(25),
  ]);

  const regs = (regsRes.data || []) as Record<string, any>[];
  const plans = (plansRes.data || []) as Record<string, any>[];
  const profs = (usersRes.data || []) as Record<string, any>[];
  const profMap = new Map(profs.map((p) => [p.id, p]));
  // Make sure every customer with a pending payment has their profile loaded.
  const missing = Array.from(
    new Set([...regs, ...plans].map((p) => p.user_id).filter((id) => !profMap.has(id)))
  );
  if (missing.length > 0) {
    const { data: extra } = await svc.from("profiles").select("*").in("id", missing);
    ((extra || []) as Record<string, any>[]).forEach((p) => profMap.set(p.id, p));
  }

  async function sign(p: Record<string, any>): Promise<string | null> {
    if (!p.screenshot_url) return null;
    const { data } = await svc.storage
      .from("payment-proofs")
      .createSignedUrl(p.screenshot_url, 60 * 30);
    return data?.signedUrl || null;
  }

  const pendingRegistrations: RegRow[] = await Promise.all(
    regs.map(async (p) => {
      const prof = profMap.get(p.user_id);
      return {
        id: p.id,
        userId: String(p.user_id),
        amount: p.amount,
        currency: p.currency,
        network: p.network,
        transactionReference: p.transaction_reference || null,
        screenshotName: p.screenshot_name || null,
        screenshotData: null,
        screenshotUrl: await sign(p),
        createdAt: String(p.created_at),
        status: p.status,
        userName: prof?.full_name || null,
        userEmail: prof?.email || null,
        userPhone: prof?.phone || null,
        userCountry: prof?.country || null,
        userCountryFlag: prof?.country_flag || null,
        userRegistrationStatus: prof?.registration_status || null,
      };
    })
  );

  const pendingPlans: PlanRow[] = await Promise.all(
    plans.map(async (p) => {
      const prof = profMap.get(p.user_id);
      return {
        id: p.id,
        userId: String(p.user_id),
        amount: p.amount,
        currency: p.currency,
        planCode: p.plan_code || null,
        planName: p.plan_name || null,
        network: p.network,
        transactionReference: p.transaction_reference || null,
        screenshotName: p.screenshot_name || null,
        screenshotData: null,
        screenshotUrl: await sign(p),
        createdAt: String(p.created_at),
        status: p.status,
        userName: prof?.full_name || null,
        userEmail: prof?.email || null,
        userPhone: prof?.phone || null,
        userActivePlan: prof?.active_plan || null,
        userPendingPlan: prof?.pending_plan || null,
      };
    })
  );

  const recentUsers: UserRow[] = profs.map((p) => ({
    id: String(p.id),
    fullName: p.full_name,
    email: p.email || "",
    phone: p.phone || "",
    country: p.country || "",
    registrationStatus: p.registration_status || "pending",
    activePlan: p.active_plan || "none",
    planStatus: p.plan_status || "none",
    pendingPlan: p.pending_plan || null,
    createdAt: String(p.created_at),
  }));

  return { pendingRegistrations, pendingPlans, recentUsers };
}

async function fetchLocalAdminData() {
  const [pendingRegistrations, pendingPlans, recentUsers] = await Promise.all([
    db
      .select({
        id: payments.id,
        userId: payments.userId,
        amount: payments.amount,
        currency: payments.currency,
        network: payments.network,
        transactionReference: payments.transactionReference,
        screenshotName: payments.screenshotName,
        screenshotData: payments.screenshotData,
        createdAt: payments.createdAt,
        status: payments.status,
        userName: users.fullName,
        userEmail: users.email,
        userPhone: users.phone,
        userCountry: users.country,
        userCountryFlag: users.countryFlag,
        userRegistrationStatus: users.registrationStatus,
      })
      .from(payments)
      .leftJoin(users, eq(users.id, payments.userId))
      .where(and(eq(payments.paymentType, "registration"), eq(payments.status, "pending")))
      .orderBy(desc(payments.id))
      .limit(50),
    db
      .select({
        id: payments.id,
        userId: payments.userId,
        amount: payments.amount,
        currency: payments.currency,
        planCode: payments.planCode,
        planName: payments.planName,
        network: payments.network,
        transactionReference: payments.transactionReference,
        screenshotName: payments.screenshotName,
        screenshotData: payments.screenshotData,
        createdAt: payments.createdAt,
        status: payments.status,
        userName: users.fullName,
        userEmail: users.email,
        userPhone: users.phone,
        userActivePlan: users.activePlan,
        userPendingPlan: users.pendingPlan,
      })
      .from(payments)
      .leftJoin(users, eq(users.id, payments.userId))
      .where(and(eq(payments.paymentType, "plan"), eq(payments.status, "pending")))
      .orderBy(desc(payments.id))
      .limit(50),
    db
      .select({
        id: users.id,
        fullName: users.fullName,
        email: users.email,
        phone: users.phone,
        country: users.country,
        registrationStatus: users.registrationStatus,
        activePlan: users.activePlan,
        planStatus: users.planStatus,
        pendingPlan: users.pendingPlan,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.id))
      .limit(25),
  ]);

  return {
    pendingRegistrations: pendingRegistrations.map((r) => ({
      ...r,
      userId: String(r.userId),
      screenshotData: r.screenshotData as string | null,
      screenshotUrl: null,
      createdAt: r.createdAt ? r.createdAt.toISOString() : "",
    })) as RegRow[],
    pendingPlans: pendingPlans.map((p) => ({
      ...p,
      userId: String(p.userId),
      screenshotData: p.screenshotData as string | null,
      screenshotUrl: null,
      createdAt: p.createdAt ? p.createdAt.toISOString() : "",
    })) as PlanRow[],
    recentUsers: recentUsers.map((u) => ({
      ...u,
      id: String(u.id),
      createdAt: u.createdAt ? u.createdAt.toISOString() : "",
    })) as UserRow[],
  };
}

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string }>;
}) {
  const { t } = await searchParams;
  // Cookie first; fall back to the ?t= token (works when the browser blocks
  // cookies inside embedded previews), exactly like the customer pages.
  const user = (await getCurrentUser()) || (await getUserByToken(t));

  // Signed-in admin (Supabase mode, or local mode with ADMIN_EMAILS) goes
  // straight to the panel — no separate admin password needed.
  if (user?.isAdmin) {
    const data = isSupabaseConfigured()
      ? await fetchSupabaseAdminData(await getRequestSupabase(t))
      : await fetchLocalAdminData();
    const adminToken = isSupabaseConfigured()
      ? t || (await getSupabaseAccessToken())
      : "";
    return (
      <main className="min-h-[calc(100vh-80px)] bg-slate-50 py-8">
        <div className="mx-auto max-w-6xl px-4">
          <AdminPanel
            preauthed
            adminName={user.fullName}
            accessToken={adminToken}
            supabaseUrl={isSupabaseConfigured() ? getSupabaseUrl() : ""}
            supabaseAnonKey={isSupabaseConfigured() ? getSupabaseAnonKey() : ""}
            pendingRegistrations={data.pendingRegistrations}
            pendingPlans={data.pendingPlans}
            recentUsers={data.recentUsers}
          />
        </div>
      </main>
    );
  }

  // Supabase mode: only admins get in; everyone else bounces.
  if (isSupabaseConfigured()) {
    redirect(user ? `/dashboard?t=${t ?? ""}` : "/signin");
  }

  // Local mode: show the password gate.
  const data = await fetchLocalAdminData();
  return (
    <main className="min-h-[calc(100vh-80px)] bg-slate-50 py-8">
      <div className="mx-auto max-w-6xl px-4">
        <AdminPanel
          pendingRegistrations={data.pendingRegistrations}
          pendingPlans={data.pendingPlans}
          recentUsers={data.recentUsers}
        />
      </div>
    </main>
  );
}
