import { redirect } from "next/navigation";
import Link from "next/link";
import {
  getCurrentUser,
  getUserByToken,
  getUserSessionToken,
} from "@/lib/auth";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { PLANS, getPlan } from "@/lib/plans";
import { Gem, Check, Zap, Clock, AlertCircle, ChevronRight } from "lucide-react";

export const metadata = { title: "Choose Your Plan — Virtuals Pro" };
export const dynamic = "force-dynamic";

export default async function PlansPage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string }>;
}) {
  const { t } = await searchParams;
  const user = (await getCurrentUser()) || (await getUserByToken(t));
  if (!user) redirect("/signin");
  if (user.isAgent) redirect(`/agent?t=${t ?? ""}`);
  if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);
  if (user.registrationStatus !== "approved") redirect(`/onboarding?t=${t ?? ""}`);
  const token = (await getUserSessionToken(user)) || t || "";

  // Check if there is a pending plan payment
  let latestPlanPay: { status: string; planCode: string | null } | null = null;
  if (isSupabaseConfigured()) {
    const sb = await getRequestSupabase(t);
    const { data } = await sb
      .from("payments")
      .select("status, plan_code")
      .eq("user_id", String(user.id))
      .eq("payment_type", "plan")
      .order("created_at", { ascending: false })
      .limit(1);
    latestPlanPay = data?.[0]
      ? { status: data[0].status, planCode: data[0].plan_code || null }
      : null;
  } else {
    const [row] = await db
      .select()
      .from(payments)
      .where(
        and(eq(payments.userId, Number(user.id)), eq(payments.paymentType, "plan"))
      )
      .orderBy(desc(payments.id))
      .limit(1);
    latestPlanPay = row
      ? { status: row.status, planCode: row.planCode }
      : null;
  }

  const activePlan = getPlan(user.activePlan);
  const pendingPlan = user.pendingPlan ? getPlan(user.pendingPlan) : null;
  const hasPending =
    user.planStatus === "pending" ||
    (latestPlanPay && latestPlanPay.status === "pending" && latestPlanPay.planCode === user.pendingPlan);

  return (
    <main className="min-h-[calc(100vh-80px)] bg-gradient-to-b from-white to-red-50/40 pb-16">
      <div className="mx-auto max-w-3xl px-4 py-8">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-red-600 text-white shadow-lg shadow-red-500/30">
            <Gem className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-black tracking-tight sm:text-5xl">
            Choose Your Plan
          </h1>
          <p className="mt-3 text-slate-600">
            Upgrade your predictions game. Pay once via mobile money and
            activate instantly after admin approval.
          </p>
        </div>

        {/* Status banners */}
        {activePlan && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-green-200 bg-green-50 p-4 text-green-900">
            <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-600" />
            <div className="text-sm">
              <div className="font-bold">
                You already have the {activePlan.name} plan active.
              </div>
              You can select a higher plan to upgrade at any time.
            </div>
          </div>
        )}
        {hasPending && pendingPlan && !activePlan && (
          <div className="mb-6 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-900">
            <Clock className="mt-0.5 h-5 w-5 flex-shrink-0 text-amber-600" />
            <div className="text-sm">
              Your <span className="font-bold">{pendingPlan.name} Plan</span>{" "}
              payment is awaiting admin approval. You&apos;ll see Smart
              Predictions unlock shortly after confirmation.
            </div>
          </div>
        )}

        <div className="grid gap-5 sm:grid-cols-2">
          {PLANS.map((plan) => {
            const isCurrentActive = activePlan?.code === plan.code;
            const isPending =
              hasPending && pendingPlan?.code === plan.code;
            return (
              <div
                key={plan.code}
                className={
                  "relative rounded-3xl border bg-white p-6 shadow-sm transition hover:shadow-md " +
                  (plan.highlight
                    ? "border-red-300 ring-2 ring-red-200"
                    : "border-slate-200")
                }
              >
                {plan.badge && (
                  <span className="absolute right-4 top-4 rounded-full bg-red-600 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-white shadow">
                    {plan.badge}
                  </span>
                )}
                <h3 className="text-2xl font-black">{plan.name}</h3>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="text-xl font-semibold text-slate-500">
                    GHS
                  </span>
                  <span className="bg-gradient-to-r from-red-500 to-red-700 bg-clip-text text-5xl font-black tracking-tight text-transparent">
                    {plan.amount}
                  </span>
                </div>
                <p className="mt-1 text-sm font-medium text-slate-500">
                  {plan.totalPredictions} · {plan.duration}
                </p>

                <div className="my-5 h-px bg-slate-100" />

                <ul className="space-y-2 text-[15px] text-slate-700">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-5 w-5 flex-shrink-0 text-green-500" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-6">
                  {isCurrentActive ? (
                    <button
                      disabled
                      className="w-full rounded-full border-2 border-green-500 bg-green-50 py-3.5 text-base font-bold text-green-700"
                    >
                      <Check className="mr-1 inline h-5 w-5" />
                      Active
                    </button>
                  ) : isPending ? (
                    <button
                      disabled
                      className="w-full rounded-full border-2 border-amber-300 bg-amber-50 py-3.5 text-base font-bold text-amber-800"
                    >
                      <Clock className="mr-1 inline h-5 w-5" />
                      Pending review
                    </button>
                  ) : (
                    <Link
                      href={`/plans/activate?plan=${plan.code}&t=${token}`}
                      className={
                        "inline-flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-base font-bold transition " +
                        (plan.buttonVariant === "primary"
                          ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-lg shadow-red-500/30 hover:brightness-105"
                          : "border-2 border-red-500 bg-white text-red-600 hover:bg-red-50")
                      }
                    >
                      <Zap className="h-5 w-5" />
                      Activate Plan
                      <ChevronRight className="h-5 w-5" />
                    </Link>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-8 flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600">
          <AlertCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-red-500" />
          <div>
            After clicking &ldquo;Activate Plan&rdquo;, you&apos;ll be shown the
            mobile-money payment details. Send the exact amount and upload your
            receipt screenshot. Access is granted within a few hours after admin
            review.
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link
            href={`/dashboard?t=${token}`}
            className="text-sm font-semibold text-red-600 hover:text-red-700"
          >
            ← Back to dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}
