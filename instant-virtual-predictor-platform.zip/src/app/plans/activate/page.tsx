import { redirect } from "next/navigation";
import {
  getCurrentUser,
  getUserByToken,
  getUserSessionToken,
} from "@/lib/auth";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { PaymentFlow } from "@/components/PaymentFlow";
import { getPlan, PLANS } from "@/lib/plans";

export const metadata = { title: "Activate Plan — Virtuals Pro" };
export const dynamic = "force-dynamic";

export default async function PlanActivatePage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string; t?: string }>;
}) {
  const params = await searchParams;
  const user = (await getCurrentUser()) || (await getUserByToken(params.t));
  if (!user) redirect("/signin");
  if (user.isAgent) redirect(`/agent?t=${params.t ?? ""}`);
  if (user.isAdmin) redirect(`/admin?t=${params.t ?? ""}`);
  if (user.registrationStatus !== "approved") redirect("/onboarding");
  const token = (await getUserSessionToken(user)) || params.t || "";

  const planCode = params.plan || "basic";
  const plan = getPlan(planCode) || PLANS[0];

  // Find existing pending payment for this plan to prefill
  let existingRef: string | null = null;
  if (isSupabaseConfigured()) {
    const sb = await getRequestSupabase(params.t);
    const { data } = await sb
      .from("payments")
      .select("transaction_reference")
      .eq("user_id", String(user.id))
      .eq("payment_type", "plan")
      .eq("plan_code", plan.code)
      .order("created_at", { ascending: false })
      .limit(1);
    existingRef = data?.[0]?.transaction_reference || null;
  } else {
    const [existing] = await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.userId, Number(user.id)),
          eq(payments.paymentType, "plan"),
          eq(payments.planCode, plan.code)
        )
      )
      .orderBy(desc(payments.id))
      .limit(1);
    existingRef = existing?.transactionReference ?? null;
  }

  const config = {
    kind: "plan" as const,
    title: `Activate ${plan.name} Plan`,
    subtitle: "Complete your payment to continue",
    amount: plan.amount,
    currency: user.currency || "GHS",
    subtitleExtra: `${plan.name} Plan · ${plan.duration}`,
    successTitle: "Plan payment submitted!",
    successMessage: `Your ${plan.name} Plan payment proof has been received. We'll activate your access shortly after admin review.`,
    backHref: `/plans?t=${token}`,
    backLabel: "Back to plans",
    cancelHref: `/plans?t=${token}`,
    planCode: plan.code,
    planName: plan.name,
  };

  return (
    <main className="min-h-[calc(100vh-80px)] bg-gradient-to-b from-white to-red-50/50">
      <div className="mx-auto max-w-2xl px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">
            {config.title}
          </h1>
          <p className="mt-2 text-slate-600">{config.subtitle}</p>
        </div>
        <PaymentFlow
          config={config}
          existingRef={existingRef}
          userToken={token}
        />
      </div>
    </main>
  );
}
