import { redirect } from "next/navigation";
import {
  getCurrentUser,
  getUserByToken,
  getUserSessionToken,
} from "@/lib/auth";
import { getPlan } from "@/lib/plans";
import { dailyLimitForPlan } from "@/lib/predictions";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";
import { ProfileView } from "@/components/ProfileView";

export const metadata = { title: "Profile — Virtuals Pro" };
export const dynamic = "force-dynamic";

function startOfTodayISO(): string {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

export default async function ProfilePage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string }>;
}) {
  const { t } = await searchParams;
  const user = (await getCurrentUser()) || (await getUserByToken(t));
  if (!user) redirect("/signin");
  if (user.isAgent) redirect(`/agent?t=${t ?? ""}`);
  if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);

  const token = (await getUserSessionToken(user)) || t || "";
  const plan = getPlan(user.activePlan);
  const limit = dailyLimitForPlan(user.activePlan);

  let usedToday = 0;
  let memberSince: string | null = null;

  if (isSupabaseConfigured()) {
    try {
      const sb = await getRequestSupabase(t);
      const { count } = await sb
        .from("predictions")
        .select("id", { count: "exact", head: true })
        .eq("user_id", String(user.id))
        .gte("created_at", startOfTodayISO());
      usedToday = count ?? 0;

      const { data: prof } = await sb
        .from("profiles")
        .select("created_at")
        .eq("id", String(user.id))
        .maybeSingle();
      if (prof?.created_at) memberSince = String(prof.created_at);
    } catch {
      // graceful: usage/member-since may be unavailable
    }
  }

  if (!memberSince && user.createdAt) {
    memberSince =
      user.createdAt instanceof Date
        ? user.createdAt.toISOString()
        : String(user.createdAt);
  }

  return (
    <ProfileView
      data={{
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        country: user.country,
        countryFlag: user.countryFlag,
        currency: user.currency,
        registrationStatus: user.registrationStatus,
        activePlan: user.activePlan,
        planStatus: user.planStatus,
        pendingPlan: user.pendingPlan,
        planName: plan?.name || null,
        dailyLimit: limit,
        usedToday,
        memberSince,
      }}
      token={token}
    />
  );
}
