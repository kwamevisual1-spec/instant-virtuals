import { redirect } from "next/navigation";
import { getCurrentUser, getUserByToken, getUserSessionToken } from "@/lib/auth";
import { DashboardClient } from "./DashboardClient";
import { getPlan } from "@/lib/plans";

export const metadata = { title: "Dashboard — Virtuals Pro" };
export const dynamic = "force-dynamic";

const MATCHES = [
  {
    id: 1,
    league: "VIRTUAL LIGUE 1",
    date: "31 Aug · 20:45",
    homeCode: "BAY",
    homeName: "Bayern Munich",
    awayCode: "FEN",
    awayName: "Fenerbahce",
    pick: "Fenerbahce",
    pickSide: "away" as const,
    winRate: 97,
  },
  {
    id: 2,
    league: "VIRTUAL SERIE A",
    date: "31 Aug · 20:45",
    homeCode: "CHE",
    homeName: "Chelsea",
    awayCode: "OLM",
    awayName: "Marseille",
    pick: "Chelsea",
    pickSide: "home" as const,
    winRate: 92,
  },
  {
    id: 3,
    league: "VIRTUAL SUPER CUP",
    date: "31 Aug · 20:45",
    homeCode: "INT",
    homeName: "Inter Milan",
    awayCode: "NAP",
    awayName: "Napoli",
    pick: "Napoli",
    pickSide: "away" as const,
    winRate: 91,
  },
  {
    id: 4,
    league: "VIRTUAL LA LIGA",
    date: "31 Aug · 20:45",
    homeCode: "RMA",
    homeName: "Real Madrid",
    awayCode: "BAR",
    awayName: "Barcelona",
    pick: "Real Madrid",
    pickSide: "home" as const,
    winRate: 89,
  },
];

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string; as?: string }>;
}) {
  const { t, as } = await searchParams;
  const user = (await getCurrentUser()) || (await getUserByToken(t));
  if (!user) redirect("/signin");
  // Admins may open the customer view (view switcher); everyone else is routed
  // to their own area.
  const adminPreview = Boolean(user.isAdmin) && as === "customer";
  if (!adminPreview) {
    if (user.isAgent) redirect(`/agent?t=${t ?? ""}`);
    if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);
    if (user.registrationStatus !== "approved") redirect(`/onboarding?t=${t ?? ""}`);
  }

  // Prefer a fresh token from the session cookie; fall back to the token
  // the user arrived with (works when cookies are blocked in previews).
  const token = (await getUserSessionToken(user)) || t || "";
  const pendingPlanName = user.pendingPlan
    ? getPlan(user.pendingPlan)?.name || null
    : null;
  const activePlanName = user.activePlan
    ? getPlan(user.activePlan)?.name || null
    : null;

  return (
    <DashboardClient
      user={user}
      matches={MATCHES}
      planStatus={user.planStatus as "none" | "pending" | "active"}
      pendingPlanName={pendingPlanName}
      activePlanName={activePlanName}
      hasActivePlan={adminPreview ? true : user.activePlan !== "none"}
      userToken={token}
      previewNote={adminPreview ? "Admin preview — this is the customer experience." : undefined}
      adminPreview={adminPreview}
    />
  );
}
