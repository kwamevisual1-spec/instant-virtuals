import Link from "next/link";
import { redirect } from "next/navigation";
import {
  getCurrentUser,
  getUserByToken,
  getUserSessionToken,
} from "@/lib/auth";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";
import { BottomNav } from "@/components/BottomNav";
import { History as HistoryIcon, Zap, Inbox, Shield, Plane, Handshake } from "lucide-react";

export const metadata = { title: "Prediction History — Virtuals Pro" };
export const dynamic = "force-dynamic";

type Row = {
  id: number | string;
  league: string | null;
  home_team: string | null;
  away_team: string | null;
  pick: string | null;
  win_rate: number | null;
  source_screenshot: string | null;
  created_at: string | null;
};

function fmt(v: string | null): string {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function sideOf(pick: string | null, home: string | null, away: string | null) {
  if (pick && /draw/i.test(pick)) return "draw" as const;
  if (pick && away && pick === away) return "away" as const;
  return "home" as const;
}

export default async function HistoryPage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string }>;
}) {
  const { t } = await searchParams;
  const user = (await getCurrentUser()) || (await getUserByToken(t));
  if (!user) redirect("/signin");
  if (user.isAgent) redirect(`/agent?t=${t ?? ""}`);
  if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);

  const token = (await getUserSessionToken(user)) || t || "";

  let rows: Row[] = [];
  if (isSupabaseConfigured()) {
    try {
      const sb = await getRequestSupabase(t);
      const { data, error } = await sb
        .from("predictions")
        .select("*")
        .eq("user_id", String(user.id))
        .order("created_at", { ascending: false })
        .limit(50);
      if (!error && data) rows = data as Row[];
    } catch {
      rows = [];
    }
  }

  return (
    <main className="relative bg-gradient-to-b from-white via-white to-red-50/40 pb-28">
      <div className="mx-auto max-w-2xl px-4 py-6">
        <div className="mb-6">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-red-600">
            <HistoryIcon className="h-4 w-4" />
            Your record
          </div>
          <h1 className="mt-1 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl">
            Prediction History
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            Every smart pick you&apos;ve unlocked on Virtuals Pro.
          </p>
        </div>

        {rows.length === 0 ? (
          <div className="rounded-3xl border-2 border-dashed border-slate-200 bg-white p-10 text-center">
            <div className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-50 text-slate-400">
              <Inbox className="h-7 w-7" />
            </div>
            <h2 className="text-lg font-extrabold text-slate-900">
              No predictions yet
            </h2>
            <p className="mx-auto mt-2 max-w-sm text-sm text-slate-500">
              Upload a virtual match screenshot in the Smart Match Predictor and
              your picks will appear here.
            </p>
            <Link
              href={`/dashboard?t=${encodeURIComponent(token)}`}
              className="btn-primary mx-auto mt-6 max-w-xs !h-12 !text-sm"
            >
              <Zap className="h-4 w-4 fill-white" />
              Go to predictor
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {rows.map((r) => {
              const side = sideOf(r.pick, r.home_team, r.away_team);
              const Icon = side === "draw" ? Handshake : side === "home" ? Shield : Plane;
              return (
                <article
                  key={String(r.id)}
                  className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
                >
                  <div className="absolute left-0 top-0 h-full w-1 bg-gradient-to-b from-red-500 to-red-700" />
                  <div className="flex items-center gap-3 p-4 pl-5">
                    <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-red-600 text-white">
                      <Icon className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[10px] font-bold uppercase tracking-[0.18em] text-slate-400">
                        {r.league || "Virtual League"}
                      </div>
                      <div className="truncate text-sm font-extrabold text-slate-900">
                        {r.home_team || "—"} <span className="font-semibold text-slate-400">vs</span>{" "}
                        {r.away_team || "—"}
                      </div>
                      <div className="text-xs text-slate-500">
                        {r.source_screenshot ? `${r.source_screenshot} · ` : ""}
                        {fmt(r.created_at)}
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <div className="text-[10px] font-bold uppercase tracking-widest text-red-600">
                        Pick
                      </div>
                      <div className="max-w-[110px] truncate text-sm font-extrabold text-slate-900">
                        {r.pick || "—"}
                      </div>
                      {typeof r.win_rate === "number" && (
                        <div className="text-xs font-extrabold text-emerald-500">
                          {r.win_rate}%
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>

      <BottomNav token={token} active="history" />
    </main>
  );
}
