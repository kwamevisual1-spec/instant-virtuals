import { ResetPasswordForm } from "./ResetPasswordForm";

export const metadata = { title: "Set new password — Virtuals Pro" };

export default function ResetPasswordPage() {
  return (
    <main className="hero-red-bg min-h-[calc(100vh-80px)] py-8 sm:py-12">
      <ResetPasswordForm />
    </main>
  );
}
