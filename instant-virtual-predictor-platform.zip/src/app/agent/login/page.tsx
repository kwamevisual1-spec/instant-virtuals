import { redirect } from "next/navigation";

/** Agents use the same login page as everyone else; the right portal opens
 * automatically based on the account. This route only exists for old links. */
export default function Page() {
  redirect("/signin");
}
