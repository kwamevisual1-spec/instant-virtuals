import { redirect } from "next/navigation";
import { getCurrentUser, getUserByToken, getUserSessionToken } from "@/lib/auth";
import { getRequestSupabase } from "@/lib/supabase";
import { AgentDashboard } from "./AgentDashboard";

export const dynamic = "force-dynamic";
export const metadata = { title: "Agent Portal — Virtuals Pro" };

export default async function Page({ searchParams }: { searchParams: Promise<{ t?: string; as?: string }> }) {
  const { t, as } = await searchParams;
  const user = (await getUserByToken(t)) || (await getCurrentUser());
  if (!user) redirect("/signin");
  const token = (await getUserSessionToken(user)) || t || "";

  // Only an admin may preview another agent's portal (view switcher).
  const previewAgentId = user.isAdmin && as ? as : null;

  if (!previewAgentId) {
    if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);
    if (!user.isAgent) redirect(`/dashboard?t=${t ?? ""}`);
    const sb = await getRequestSupabase(t);
    const { data: agent } = await sb.from("agents").select("status").eq("user_id", user.id).maybeSingle();
    if (agent?.status !== "active") {
      redirect("/signin?error=" + encodeURIComponent("This agent account is suspended or unavailable."));
    }
  }

  return <AgentDashboard token={token} previewAgentId={previewAgentId} />;
}
