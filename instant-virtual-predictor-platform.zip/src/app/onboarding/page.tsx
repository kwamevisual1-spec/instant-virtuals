import { redirect } from "next/navigation";
import {
  getCurrentUser,
  getUserByToken,
  getUserSessionToken,
} from "@/lib/auth";
import { db } from "@/db";
import { payments } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { PaymentFlow } from "@/components/PaymentFlow";
import { REGISTRATION_FEE } from "@/lib/plans";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";
import { decryptSignup } from "@/lib/signupToken";

export const metadata = { title: "Registration Fee — Virtuals Pro" };
export const dynamic = "force-dynamic";

export default async function OnboardingPage({
  searchParams,
}: {
  searchParams: Promise<{ t?: string; s?: string }>;
}) {
  const { t, s } = await searchParams;

  // New customer who has NOT paid yet: nothing exists in Supabase. Their
  // details ride in an encrypted ticket; the account is created only when
  // they submit payment proof.
  if (isSupabaseConfigured() && s) {
    const pending = decryptSignup(s);
    if (!pending) {
      redirect(
        "/?error=" +
          encodeURIComponent(
            "Your registration session expired. Please create your account again."
          )
      );
    }
    return (
      <main className="min-h-[calc(100vh-80px)] bg-gradient-to-b from-white to-red-50/50">
        <div className="mx-auto max-w-2xl px-4 py-10">
          <div className="mb-8">
            <h1 className="text-3xl font-black tracking-tight sm:text-4xl">
              Registration Fee
            </h1>
            <p className="mt-2 text-slate-600">
              Complete your payment to continue
            </p>
          </div>
          <PaymentFlow
            config={{
              kind: "registration",
              title: "Registration Fee",
              subtitle: "Complete your payment to continue",
              amount: REGISTRATION_FEE,
              currency: pending.currency || "GHS",
              successTitle: "Registration submitted!",
              successMessage:
                "Your registration payment proof has been received. Please sign in once your account is approved by admin.",
            }}
            signupToken={s}
          />
        </div>
      </main>
    );
  }
  const user =
    (t ? await getUserByToken(t) : null) || (await getCurrentUser());
  if (!user) redirect("/");
  if (user.isAgent) redirect(`/agent?t=${t ?? ""}`);
  if (user.isAdmin) redirect(`/admin?t=${t ?? ""}`);
  if (user.registrationStatus === "approved") redirect("/dashboard");

  const token = (await getUserSessionToken(user)) || t || "";

  // Find existing pending registration payment (to pre-fill reference)
  let existingRef: string | null = null;
  if (isSupabaseConfigured()) {
    const sb = await getRequestSupabase(t);
    const { data } = await sb
      .from("payments")
      .select("transaction_reference")
      .eq("user_id", String(user.id))
      .eq("payment_type", "registration")
      .order("created_at", { ascending: false })
      .limit(1);
    existingRef = data?.[0]?.transaction_reference || null;
  } else {
    const [existingReg] = await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.userId, Number(user.id)),
          eq(payments.paymentType, "registration")
        )
      )
      .orderBy(desc(payments.id))
      .limit(1);
    existingRef = existingReg?.transactionReference ?? null;
  }

  const config = {
    kind: "registration" as const,
    title: "Registration Fee",
    subtitle: "Complete your payment to continue",
    amount: REGISTRATION_FEE,
    currency: user.currency || "GHS",
    successTitle: "Registration submitted!",
    successMessage:
      "Your registration payment proof has been received. Please sign in again once your account is approved by admin.",
  };

  return (
    <main className="min-h-[calc(100vh-80px)] bg-gradient-to-b from-white to-red-50/50">
      <div className="mx-auto max-w-2xl px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-black tracking-tight sm:text-4xl">
            {config.title}
          </h1>
          <p className="mt-2 text-slate-600">{config.subtitle}</p>
        </div>
        <PaymentFlow
          config={config}
          existingRef={existingRef}
          userToken={token}
        />
      </div>
    </main>
  );
}
