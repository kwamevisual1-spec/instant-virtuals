import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { createClient } from "@supabase/supabase-js";
import { isSupabaseConfigured, getSupabaseUrl, getSupabaseAnonKey } from "@/lib/supabase";

export const runtime = "nodejs";

const GENERIC_OK =
  "If an account exists for that email, a password reset link is on its way. Check your inbox (and spam folder).";

async function siteOrigin(): Promise<string> {
  const h = await headers();
  const host = h.get("x-forwarded-host") || h.get("host") || "localhost:3000";
  const proto =
    (h.get("x-forwarded-proto") || "").split(",")[0].trim() ||
    (host.startsWith("localhost") || host.startsWith("127.") ? "http" : "https");
  return `${proto}://${host}`;
}

export async function POST(req: Request) {
  try {
    const { email } = await req.json().catch(() => ({ email: "" }));
    const normEmail = String(email || "").trim().toLowerCase();
    if (!normEmail || !/^\S+@\S+\.\S+$/.test(normEmail)) {
      return NextResponse.json(
        { error: "Please enter a valid email address." },
        { status: 400 }
      );
    }

    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: "Password reset by email isn't available right now. Please contact support." },
        { status: 503 }
      );
    }

    // Implicit flow: the emailed link works on ANY device/browser
    // (no code-verifier cookie required).
    const sb = createClient(
      getSupabaseUrl(),
      getSupabaseAnonKey(),
      { auth: { flowType: "implicit", persistSession: false, autoRefreshToken: false } }
    );

    const redirectTo = `${await siteOrigin()}/reset-password`;
    const { error } = await sb.auth.resetPasswordForEmail(normEmail, { redirectTo });

    if (error) {
      const raw = error.message || "";
      if (/rate limit|too many|seconds/i.test(raw)) {
        return NextResponse.json(
          {
            error:
              "Too many reset requests. Please wait a few minutes and try again.",
          },
          { status: 429 }
        );
      }
      console.error("resetPasswordForEmail error", error);
      // Don't reveal whether the email exists.
    }

    return NextResponse.json({ ok: true, message: GENERIC_OK });
  } catch (err) {
    console.error("Forgot password error", err);
    return NextResponse.json(
      { error: "Server error. Please try again." },
      { status: 500 }
    );
  }
}
