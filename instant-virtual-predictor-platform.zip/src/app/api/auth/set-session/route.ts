import { NextResponse } from "next/server";
import { isSupabaseConfigured, createServerSupabase } from "@/lib/supabase";

export const runtime = "nodejs";

/**
 * Keeps the server-side login cookie in step with a session the browser has
 * just renewed (so the two never disagree about which refresh token is current).
 */
export async function POST(req: Request) {
  if (!isSupabaseConfigured()) {
    return NextResponse.json({ ok: false }, { status: 503 });
  }
  const { access_token, refresh_token } = await req.json().catch(() => ({}));
  if (!access_token || !refresh_token) {
    return NextResponse.json({ error: "Missing tokens." }, { status: 400 });
  }
  const sb = await createServerSupabase();
  const { error } = await sb.auth.setSession({
    access_token: String(access_token),
    refresh_token: String(refresh_token),
  });
  if (error) {
    return NextResponse.json({ error: "Session could not be saved." }, { status: 401 });
  }
  return NextResponse.json({ ok: true });
}
