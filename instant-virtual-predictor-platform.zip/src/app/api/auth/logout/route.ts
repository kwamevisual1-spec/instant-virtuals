import { NextResponse } from "next/server";
import { destroySession } from "@/lib/auth";
import { isSupabaseConfigured, createServerSupabase } from "@/lib/supabase";

export const runtime = "nodejs";

export async function POST() {
  try {
    if (isSupabaseConfigured()) {
      const supabase = await createServerSupabase();
      await supabase.auth.signOut();
    }
  } catch {
    // fall through to local cookie clear
  }
  await destroySession();
  return NextResponse.json({ ok: true });
}
