import { NextResponse } from "next/server";
import { isSupabaseConfigured, getSupabaseUrl, getSupabaseAnonKey } from "@/lib/supabase";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { accessToken, password } = await req.json().catch(() => ({}));

    if (!isSupabaseConfigured()) {
      return NextResponse.json(
        { error: "Password reset isn't available right now." },
        { status: 503 }
      );
    }
    if (!accessToken || typeof accessToken !== "string") {
      return NextResponse.json(
        { error: "This reset link is invalid or has expired. Please request a new one." },
        { status: 400 }
      );
    }
    if (!password || String(password).length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters." },
        { status: 400 }
      );
    }

    // The recovery link gives a short-lived access token. Use it to update
    // that user's password directly through Supabase Auth.
    const url = getSupabaseUrl();
    const anon = getSupabaseAnonKey();
    const res = await fetch(`${url}/auth/v1/user`, {
      method: "PUT",
      headers: {
        apikey: anon,
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ password: String(password) }),
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      const raw = String(data?.msg || data?.message || data?.error_description || "");
      let msg = "Could not update your password. Please request a new reset link.";
      if (/different from the old password|same password/i.test(raw)) {
        msg = "Your new password must be different from your old password.";
      } else if (/expired|invalid|jwt|missing|not authenticated/i.test(raw) || res.status === 401 || res.status === 403) {
        msg = "This reset link is invalid or has expired. Please request a new one.";
      } else if (/weak|at least/i.test(raw)) {
        msg = "That password is too weak. Please choose a stronger one.";
      }
      return NextResponse.json({ error: msg }, { status: 400 });
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Reset password error", err);
    return NextResponse.json(
      { error: "Server error. Please try again." },
      { status: 500 }
    );
  }
}
