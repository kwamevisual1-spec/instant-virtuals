import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, createSession } from "@/lib/auth";
import { signUserToken } from "@/lib/token";
import { isSupabaseConfigured, createServerSupabase } from "@/lib/supabase";
import { encryptSignup } from "@/lib/signupToken";
import { ADMIN_EMAIL } from "@/lib/config";
import { firstReferral } from "@/lib/referrals";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const {
      fullName,
      email,
      phone,
      country,
      countryFlag,
      currency,
      password,
    } = body || {};

    if (!fullName || !email || !phone || !password) {
      return NextResponse.json(
        { error: "Please fill all required fields." },
        { status: 400 }
      );
    }
    if (String(password).length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters." },
        { status: 400 }
      );
    }

    /* ------------------------------ Supabase ------------------------------ */
    if (isSupabaseConfigured()) {
      const supabase = await createServerSupabase();
      const normEmail = String(email).trim().toLowerCase();

      // The admin account is created immediately (it never pays the fee).
      if (normEmail === ADMIN_EMAIL) {
        const { data, error } = await supabase.auth.signUp({
          email: normEmail,
          password: String(password),
          options: {
            data: {
              full_name: String(fullName).trim(),
              phone: String(phone).trim(),
              country: String(country || "Ghana"),
              country_flag: String(countryFlag || "GH"),
              currency: String(currency || "GHS"),
            },
          },
        });
        const exists =
          (error && /already|exists/i.test(error.message)) ||
          (data?.user && Array.isArray(data.user.identities) && data.user.identities.length === 0);
        if (exists) {
          return NextResponse.json(
            { error: "This account already exists. Please sign in instead." },
            { status: 409 }
          );
        }
        if (error) {
          return NextResponse.json({ error: error.message }, { status: 400 });
        }
        if (!data.session) {
          return NextResponse.json(
            {
              error:
                "Email confirmation is still switched on in Supabase. Turn OFF \"Confirm email\" (Authentication → Sign In / Providers → Email) and try again.",
            },
            { status: 400 }
          );
        }
        return NextResponse.json({
          ok: true,
          isAdmin: true,
          nextPath: `/admin?t=${encodeURIComponent(data.session.access_token)}`,
          session: {
            access_token: data.session.access_token,
            refresh_token: data.session.refresh_token,
            expires_at: data.session.expires_at,
          },
        });
      }

      // Customers: do NOT create anything in Supabase yet.
      // Only block the email if a PAID (or admin) account already uses it.
      const { data: taken } = await supabase.rpc("email_has_paid_account", {
        p_email: normEmail,
      });
      if (taken === true) {
        return NextResponse.json(
          { error: "An account with this email already exists. Please sign in instead." },
          { status: 409 }
        );
      }

      // Hold the details in an encrypted ticket that travels with the
      // registration-fee page. The account is created after payment proof.
      const ticket = encryptSignup({
        fullName: String(fullName).trim(),
        email: normEmail,
        phone: String(phone).trim(),
        country: String(country || "Ghana"),
        countryFlag: String(countryFlag || "GH"),
        currency: String(currency || "GHS"),
        password: String(password),
        referralCode: await firstReferral(),
      });
      return NextResponse.json({
        ok: true,
        nextPath: `/onboarding?s=${encodeURIComponent(ticket)}`,
      });
    }

    /* ------------------------------- Local -------------------------------- */
    const existing = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, String(email).toLowerCase()))
      .limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: "An account with this email already exists." },
        { status: 409 }
      );
    }

    const passwordHash = await hashPassword(String(password));
    const avatarInitial = String(fullName)
      .split(" ")
      .map((p: string) => p[0])
      .slice(0, 1)
      .join("")
      .toUpperCase();

    const [created] = await db
      .insert(users)
      .values({
        fullName: String(fullName),
        email: String(email).toLowerCase(),
        phone: String(phone),
        country: String(country || "Ghana"),
        countryFlag: String(countryFlag || "🇬🇭"),
        currency: String(currency || "GHS"),
        passwordHash,
        registrationStatus: "pending",
        avatarInitial,
      })
      .returning({ id: users.id });

    await createSession(created.id);
    const token = signUserToken(created.id);
    return NextResponse.json({
      ok: true,
      userId: created.id,
      nextPath: `/onboarding?t=${encodeURIComponent(token)}`,
    });
  } catch (err) {
    console.error("Signup error", err);
    return NextResponse.json(
      { error: "Server error. Please try again." },
      { status: 500 }
    );
  }
}
