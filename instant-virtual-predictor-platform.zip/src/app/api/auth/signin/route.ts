import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, payments } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { verifyPassword, createSession } from "@/lib/auth";
import { signUserToken } from "@/lib/token";
import { isSupabaseConfigured, createServerSupabase } from "@/lib/supabase";
import { fetchSupabaseProfile } from "@/lib/supabaseData";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, password } = body || {};
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required." },
        { status: 400 }
      );
    }
    const normEmail = String(email).toLowerCase();

    /* ------------------------------ Supabase ------------------------------ */
    if (isSupabaseConfigured()) {
      const supabase = await createServerSupabase();
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normEmail,
        password: String(password),
      });
      if (error || !data?.user || !data.session) {
        const raw = error?.message || "Sign in failed.";
        let msg = raw;
        if (/invalid login credentials/i.test(raw)) {
          msg = "Incorrect email or password.";
        } else if (/email not confirmed/i.test(raw)) {
          msg =
            "This email isn't confirmed yet. Turn off \"Confirm email\" in Supabase (Authentication → Sign In / Providers → Email) or confirm the account.";
        }
        return NextResponse.json({ error: msg }, { status: 401 });
      }

      const token = data.session.access_token;
      const profile = await fetchSupabaseProfile(
        supabase,
        data.user.id,
        data.user.email || normEmail
      );
      if (!profile) {
        await supabase.auth.signOut();
        return NextResponse.json(
          { error: "Profile not found. Please run supabase/schema.sql in the Supabase SQL Editor." },
          { status: 400 }
        );
      }

      // Agent credentials -> their separate portal, never the customer dashboard.
      if (profile.isAgent) {
        const { data: agent } = await supabase.from("agents").select("status").eq("user_id", data.user.id).maybeSingle();
        if (agent?.status !== "active") {
          await supabase.auth.signOut();
          return NextResponse.json({ error: "Your agent account is suspended or unavailable. Contact the administrator." }, { status: 403 });
        }
        return NextResponse.json({ ok: true, nextPath: `/agent?t=${encodeURIComponent(token)}`, session: {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at,
        } });
      }
      // Admin credentials -> straight to the admin panel.
      if (profile.isAdmin) {
        return NextResponse.json({
          ok: true,
          isAdmin: true,
          nextPath: `/admin?t=${encodeURIComponent(token)}`,
          session: {
            access_token: data.session.access_token,
            refresh_token: data.session.refresh_token,
            expires_at: data.session.expires_at,
          },
        });
      }

      if (profile.registrationStatus === "rejected") {
        await supabase.auth.signOut();
        return NextResponse.json(
          {
            error:
              "Your registration was rejected. Please contact support or register again.",
          },
          { status: 403 }
        );
      }

      if (profile.registrationStatus !== "approved") {
        const { data: regPays } = await supabase
          .from("payments")
          .select("status")
          .eq("user_id", data.user.id)
          .eq("payment_type", "registration")
          .order("created_at", { ascending: false })
          .limit(1);
        if (!regPays || regPays.length === 0 || regPays[0].status === "rejected") {
          // Registered but hasn't paid the fee yet -> registration fee page
          return NextResponse.json({
            ok: true,
            nextPath: `/onboarding?t=${encodeURIComponent(token)}`,
            session: {
              access_token: data.session.access_token,
              refresh_token: data.session.refresh_token,
              expires_at: data.session.expires_at,
            },
          });
        }
        await supabase.auth.signOut();
        return NextResponse.json(
          {
            error:
              "Your account is awaiting admin approval. You will be able to sign in once your registration payment has been confirmed.",
          },
          { status: 403 }
        );
      }

      return NextResponse.json({
        ok: true,
        nextPath: `/dashboard?t=${encodeURIComponent(token)}`,
        // So the header can recognise the signed-in user even when the
        // browser blocks cookies (embedded previews).
        session: {
          access_token: data.session.access_token,
          refresh_token: data.session.refresh_token,
          expires_at: data.session.expires_at,
        },
      });
    }

    /* ------------------------------- Local -------------------------------- */
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, normEmail))
      .limit(1);

    if (!user) {
      return NextResponse.json(
        { error: "No account found with that email." },
        { status: 404 }
      );
    }

    const ok = await verifyPassword(String(password), user.passwordHash);
    if (!ok) {
      return NextResponse.json(
        { error: "Incorrect email or password." },
        { status: 401 }
      );
    }

    const isLocalAdmin = (process.env.ADMIN_EMAILS || "")
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean)
      .includes(normEmail);

    if (isLocalAdmin) {
      await createSession(user.id);
      return NextResponse.json({ ok: true, isAdmin: true, nextPath: "/admin" });
    }

    if (user.registrationStatus === "rejected") {
      return NextResponse.json(
        {
          error:
            "Your registration was rejected. Please contact support or register again.",
        },
        { status: 403 }
      );
    }

    if (user.registrationStatus !== "approved") {
      const [regPay] = await db
        .select({ id: payments.id, status: payments.status })
        .from(payments)
        .where(
          and(
            eq(payments.userId, user.id),
            eq(payments.paymentType, "registration")
          )
        )
        .orderBy(desc(payments.id))
        .limit(1);
      if (!regPay || regPay.status === "rejected") {
        await createSession(user.id);
        return NextResponse.json({
          ok: true,
          nextPath: `/onboarding?t=${encodeURIComponent(signUserToken(user.id))}`,
        });
      }
      return NextResponse.json(
        {
          error:
            "Your account is awaiting admin approval. You will be able to sign in once your registration payment has been confirmed.",
        },
        { status: 403 }
      );
    }

    await createSession(user.id);
    const token = signUserToken(user.id);
    return NextResponse.json({
      ok: true,
      nextPath: `/dashboard?t=${encodeURIComponent(token)}`,
    });
  } catch (err) {
    console.error("Signin error", err);
    return NextResponse.json(
      { error: "Server error. Please try again." },
      { status: 500 }
    );
  }
}
