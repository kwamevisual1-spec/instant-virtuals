import { NextResponse } from "next/server";
import { getCurrentUser, getUserByToken } from "@/lib/auth";
import { getRequestSupabase, getSupabaseUrl, getSupabaseAnonKey, getSupabaseAccessToken } from "@/lib/supabase";

import { agentContactLinks, publicLinkStatus, publicSiteOrigin } from "@/lib/siteOrigin";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const params = new URL(req.url).searchParams;
  const t = params.get("t");
  const previewAgentId = params.get("agentId");
  const user = (await getUserByToken(t)) || (await getCurrentUser());
  if (!user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });

  const preview = Boolean(user.isAdmin && previewAgentId);
  if (!preview && (!user.isAgent || user.isAdmin)) {
    return NextResponse.json({ error: "Agent access only" }, { status: 403 });
  }

  const sb = await getRequestSupabase(t);
  const query = sb.from("agents").select("*");
  const { data: agent, error } = preview
    ? await query.eq("id", String(previewAgentId)).maybeSingle()
    : await query.eq("user_id", user.id).maybeSingle();
  if (error || !agent) return NextResponse.json({ error: "Agent account unavailable" }, { status: 404 });
  if (!preview && agent.status !== "active") return NextResponse.json({ error: "Agent account suspended or unavailable" }, { status: 403 });
  const [customers, payments, commissions] = await Promise.all([
    sb.from("profiles").select("id,full_name,created_at,registration_status,active_plan").eq("referred_agent_id", agent.id).order("created_at", { ascending: false }),
    sb.from("payments").select("id,user_id,payment_type,plan_name,amount,currency,status,transaction_reference,approved_at,created_at").eq("referred_agent_id", agent.id).order("created_at", { ascending: false }),
    sb.from("agent_commissions").select("id,customer_id,payment_id,payment_amount,commission_percentage,commission_amount,currency,status,approved_at").eq("agent_id", agent.id).order("approved_at", { ascending: false }),
  ]);
  if (customers.error || payments.error || commissions.error) return NextResponse.json({ error: customers.error?.message || payments.error?.message || commissions.error?.message }, { status: 503 });
  const c = customers.data || [], p = payments.data || [], earnings = commissions.data || [];
  const origin = publicSiteOrigin(req.headers, req.url);
  return NextResponse.json({
    agent,
    ...agentContactLinks(origin, agent.agent_code),
    publicLinks: publicLinkStatus(origin),
    customers: c,
    payments: p,
    commissions: earnings,
    preview,
    stats: {
      referred: c.length,
      registered: c.filter((u) => u.registration_status === "approved").length,
      submitted: new Set(p.map((row) => row.user_id)).size,
      approvedPaying: new Set(p.filter((row) => row.status === "approved").map((row) => row.user_id)).size,
      pending: p.filter((row) => row.status === "pending").length,
      rejected: p.filter((row) => row.status === "rejected").length,
      earned: earnings.filter((row) => row.status === "approved").reduce((sum, row) => sum + Number(row.commission_amount), 0),
      reversed: earnings.filter((row) => row.status === "reversed").reduce((sum, row) => sum + Number(row.commission_amount), 0),
    },
  }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const user = (await getUserByToken(body.accessToken)) || (await getCurrentUser());
  if (!user?.isAgent || user.isAdmin) return NextResponse.json({ error: "Agent access only" }, { status: 403 });
  const sb = await getRequestSupabase(body.accessToken);
  const { data: agent } = await sb.from("agents").select("status").eq("user_id", user.id).maybeSingle();
  if (agent?.status !== "active") return NextResponse.json({ error: "Agent suspended" }, { status: 403 });
  if (body.password) {
    if (String(body.password).length < 12) return NextResponse.json({ error: "Password must contain at least 12 characters." }, { status: 400 });
    const token = String(body.accessToken || (await getSupabaseAccessToken()) || "");
    if (!token) return NextResponse.json({ error: "Please sign in again to change your password." }, { status: 401 });
    const result = await fetch(`${getSupabaseUrl()}/auth/v1/user`, {
      method: "PUT",
      headers: { apikey: getSupabaseAnonKey(), Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ password: String(body.password) }),
    });
    if (!result.ok) {
      const data = await result.json().catch(() => ({}));
      return NextResponse.json({ error: data?.msg || data?.message || "Password update failed." }, { status: 400 });
    }
    return NextResponse.json({ ok: true });
  }
  const fullName = String(body.fullName || "").trim(), phone = String(body.phone || "").trim();
  if (fullName.length < 2 || phone.length < 5) return NextResponse.json({ error: "Enter a valid name and phone number." }, { status: 400 });
  const { error } = await sb.rpc("update_my_agent_profile", { p_name: fullName, p_phone: phone });
  return error ? NextResponse.json({ error: error.message }, { status: 400 }) : NextResponse.json({ ok: true });
}
