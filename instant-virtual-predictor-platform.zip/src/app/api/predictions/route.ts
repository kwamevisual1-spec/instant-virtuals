import { NextResponse } from "next/server";
import { getCurrentUser, getUserByToken } from "@/lib/auth";
import { getPlan } from "@/lib/plans";
import {
  PLAN_DAILY_LIMITS,
  dailyLimitForPlan,
  planAllowsMatches,
  countMatchesFromText,
  addLocalUsage,
} from "@/lib/predictions";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";

export const runtime = "nodejs";

type PredictionInput = {
  league?: string;
  homeTeam?: string;
  awayTeam?: string;
  pick?: string;
  winRate?: number;
};

async function resolveUser(body: any) {
  return (await getCurrentUser()) || (await getUserByToken(body?.userToken));
}

function startOfTodayISO(): string {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

/** How many predictions the user has already used today. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const t = url.searchParams.get("t");
  const user = await resolveUser({ userToken: t });
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const limit = dailyLimitForPlan(user.activePlan);

  if (isSupabaseConfigured()) {
    try {
      const sb = await getRequestSupabase(t);
      const { count, error } = await sb
        .from("predictions")
        .select("id", { count: "exact", head: true })
        .eq("user_id", String(user.id))
        .gte("created_at", startOfTodayISO());
      if (!error) {
        return NextResponse.json({
          ok: true,
          usedToday: count ?? 0,
          limit,
          plan: user.activePlan,
          planStatus: user.planStatus,
        });
      }
      console.error("predictions count error", error);
    } catch (err) {
      console.error("predictions GET failed", err);
    }
  }

  return NextResponse.json({
    ok: true,
    usedToday: 0,
    limit,
    plan: user.activePlan,
    planStatus: user.planStatus,
    offline: true,
  });
}

/**
 * Verify user's subscribed plan against the extracted screenshot matches,
 * check today's remaining quota, and save the predictions.
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const user = await resolveUser(body);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // This flag is not trusted by itself. The signed-in profile must really
  // have is_admin=true; ordinary customers cannot bypass plan rules.
  const adminPreview = user.isAdmin === true && body?.adminPreview === true;
  const plan = getPlan(user.activePlan);
  if (!adminPreview && (
    user.registrationStatus !== "approved" ||
    user.planStatus !== "active" ||
    !plan
  )) {
    return NextResponse.json(
      {
        error:
          "You do not have an active plan yet. Please subscribe to a plan and wait for admin approval.",
        code: "NO_PLAN",
      },
      { status: 403 }
    );
  }

  const matches: PredictionInput[] = Array.isArray(body?.matches)
    ? body.matches
        .filter((m: any) => m && (m.pick || m.homeTeam || m.awayTeam))
        .slice(0, 60)
    : [];
  if (matches.length === 0) {
    return NextResponse.json(
      { error: "No matches found to predict." },
      { status: 400 }
    );
  }

  const scannedCount = countMatchesFromText(String(body?.scannedText || ""));
  const detected = scannedCount > 0 ? scannedCount : matches.length;
  if (detected > matches.length || matches.length > detected) {
    return NextResponse.json(
      { error: "The extracted match count did not match the result rows. Please upload a clearer screenshot and try again.", code: "MATCH_COUNT_MISMATCH", detected, resultCount: matches.length },
      { status: 400 }
    );
  }

  // Authorized admin test: return an explicitly marked preview and do not
  // write predictions, consume credits, or alter any customer/agent records.
  if (adminPreview) {
    return NextResponse.json({
      ok: true,
      preview: true,
      persisted: false,
      saved: 0,
      detected,
      usedToday: 0,
      limit: null,
      plan: "Admin test mode",
    });
  }

  // 1) Validate screenshot count against the subscribed plan.
  const limit = PLAN_DAILY_LIMITS[plan!.code] ?? dailyLimitForPlan(plan!.code);
  if (!planAllowsMatches(plan!.code, detected) || (limit !== null && detected > limit)) {
    return NextResponse.json(
      {
        error: `Your screenshot contains ${detected} match${detected === 1 ? "" : "es"}, but your ${plan!.name} plan only allows ${limit} prediction${limit === 1 ? "" : "s"} per day. Please upgrade to a higher plan to analyse ${detected} match${detected === 1 ? "" : "es"}.`,
        code: "PLAN_LIMIT",
        detected,
        limit,
        plan: plan!.name,
      },
      { status: 403 }
    );
  }

  // 2) Verify today's usage in Supabase before accepting the prediction.
  if (!isSupabaseConfigured()) {
    return NextResponse.json({ error: "Prediction verification is unavailable. No result was generated." }, { status: 503 });
  }
  try {
    const sb = await getRequestSupabase(body?.userToken);
    const { count, error: countError } = await sb
      .from("predictions")
      .select("id", { count: "exact", head: true })
      .eq("user_id", String(user.id))
      .gte("created_at", startOfTodayISO());
    if (countError) {
      console.error("predictions count error", countError);
      return NextResponse.json({ error: "We couldn't verify today's prediction allowance. No result was generated. Please try again later." }, { status: 503 });
    }
    const usedToday = count ?? 0;
    if (limit !== null && usedToday + detected > limit) {
      const remaining = Math.max(0, limit - usedToday);
      return NextResponse.json(
        {
          error: `You have ${remaining} of ${limit} predictions remaining today on your ${plan!.name} plan, but this screenshot has ${detected} match${detected === 1 ? "" : "es"}. Please come back tomorrow or upgrade your plan.`,
          code: "PLAN_LIMIT",
          detected,
          limit,
          remaining,
          usedToday,
          plan: plan!.name,
        },
        { status: 403 }
      );
    }

    const rows = matches.map((m) => ({
      user_id: String(user.id),
      league: m.league ? String(m.league) : null,
      home_team: m.homeTeam ? String(m.homeTeam) : null,
      away_team: m.awayTeam ? String(m.awayTeam) : null,
      pick: m.pick ? String(m.pick) : null,
      win_rate: typeof m.winRate === "number" ? Math.round(m.winRate) : null,
      source_screenshot: body?.screenshotName ? String(body.screenshotName) : null,
    }));
    const { error: insertError } = await sb.from("predictions").insert(rows);
    if (insertError) {
      console.error("predictions insert error", insertError);
      return NextResponse.json({ error: "We couldn't save and verify these predictions. No result was generated. Please try again." }, { status: 503 });
    }
    return NextResponse.json({ ok: true, saved: detected, usedToday: usedToday + detected, limit, plan: plan!.name, preview: false });
  } catch (err) {
    console.error("predictions verification failed", err);
    return NextResponse.json({ error: "We couldn't verify your plan with the server. No result was generated. Please try again." }, { status: 503 });
  }

}
