import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { getCurrentUser, getUserByToken } from "@/lib/auth";
import { getPlan } from "@/lib/plans";
import { PLAN_DAILY_LIMITS, dailyLimitForPlan, planAllowsMatches } from "@/lib/predictions";
import { extractFixturesFromImage, isVerified, type ParsedScreenshot } from "@/lib/screenshotPipeline";
import { analyzeMatch, type MatchAnalysis } from "@/lib/model";
import { insertPredictionWithSchemaFallback } from "@/lib/predictionStore";
import { isSupabaseConfigured, getRequestSupabase } from "@/lib/supabase";

export const runtime = "nodejs";
export const maxDuration = 120;

const FRIENDLY: Record<string, { status: number; message: string; retry: boolean }> = {
  UNSUPPORTED_IMAGE: { status: 415, message: "That image format isn't supported. Upload a JPG or PNG screenshot.", retry: true },
  IMAGE_TOO_LARGE: { status: 413, message: "That image is too large. Please upload a screenshot under 8MB.", retry: true },
  UNREADABLE_IMAGE: { status: 422, message: "We couldn't read that image. Try a clearer screenshot of the match list.", retry: true },
  OCR_FAILED: { status: 422, message: "We couldn't extract any text from the image. Make sure the matches and odds are clearly visible, then try again.", retry: true },
  OCR_TIMEOUT: { status: 504, message: "Scanning took too long. Try a smaller or sharper screenshot.", retry: true },
  NO_MATCHES: { status: 422, message: "No football matches were detected in this screenshot. Make sure the team names and odds are visible.", retry: true },
};

function friendly(code: string, fallback: string) {
  return FRIENDLY[code] || { status: 500, message: fallback, retry: true };
}

function startOfTodayISO(): string {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

export async function POST(req: Request) {
  const requestId = randomUUID();
  const started = Date.now();
  const log = (msg: string, extra?: Record<string, unknown>) =>
    console.log(JSON.stringify({ requestId, msg, ...extra }));

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body.", requestId }, { status: 400 });
  }

  const user = (await getCurrentUser()) || (await getUserByToken(body?.userToken));
  if (!user) return NextResponse.json({ error: "Please sign in again.", requestId }, { status: 401 });

  const adminPreview = user.isAdmin === true && body?.adminPreview === true;
  const plan = getPlan(user.activePlan);
  if (!adminPreview && (user.registrationStatus !== "approved" || user.planStatus !== "active" || !plan)) {
    return NextResponse.json(
      { error: "You do not have an active plan yet. Subscribe to a plan and wait for admin approval.", code: "NO_PLAN", requestId },
      { status: 403 }
    );
  }

  const dataUrl = String(body?.image || "");
  if (!dataUrl.startsWith("data:image/")) {
    return NextResponse.json({ error: "Please upload a match screenshot first.", code: "EMPTY_UPLOAD", requestId }, { status: 400 });
  }

  // 1-2) upload accepted -> scanning begins
  log("scan_start", { bytes: dataUrl.length, adminPreview });

  let parsed: ParsedScreenshot;
  try {
    parsed = await extractFixturesFromImage(dataUrl, { timeoutMs: 60000 });
  } catch (err) {
    const code = err instanceof Error ? err.message : "OCR_FAILED";
    log("scan_error", { code });
    const f = friendly(code, "Something went wrong while scanning the image. Please try again.");
    return NextResponse.json({ error: f.message, code, requestId, retry: f.retry }, { status: f.status });
  }

  const verified = parsed.fixtures.filter(isVerified);
  const unverified = parsed.fixtures.filter((f) => !isVerified(f));
  log("rows_detected", { total: parsed.fixtures.length, verified: verified.length, issues: parsed.issues.length });

  if (verified.length === 0) {
    const f = FRIENDLY.NO_MATCHES;
    return NextResponse.json(
      {
        error: parsed.fixtures.length > 0
          ? "We found fixtures but couldn't verify the odds for them. Make sure each match shows Home / Draw / Away odds clearly."
          : "We couldn't confidently read a match from this screenshot. Try a sharper, less blurry crop with the teams and Home / Draw / Away odds visible.",
        code: "NO_MATCHES",
        requestId,
        retry: true,
        detected: parsed.fixtures.length,
        issues: parsed.issues,
      },
      { status: 422 }
    );
  }

  const count = verified.length;

  // Plan limit check (admin preview bypasses, without persistence).
  const limit = adminPreview ? null : PLAN_DAILY_LIMITS[plan!.code] ?? dailyLimitForPlan(plan!.code);
  if (!adminPreview && limit !== null && !planAllowsMatches(plan!.code, count)) {
    return NextResponse.json(
      {
        error: `Your screenshot has ${count} verified matches, but your ${plan!.name} plan allows ${limit} per day. Upgrade to analyse all of them.`,
        code: "PLAN_LIMIT",
        detected: count,
        limit,
        requestId,
      },
      { status: 403 }
    );
  }

  // 3-8) analyze each verified fixture independently
  const analyses: MatchAnalysis[] = verified.map((f) =>
    analyzeMatch({
      home: f.homeName,
      away: f.awayName,
      homeOdds: f.homeOdds,
      drawOdds: f.drawOdds,
      awayOdds: f.awayOdds,
      verified: true,
    })
  );
  log("analysis_done", { count, ms: Date.now() - started });

  let usedToday: number | null = 0;
  let persisted = false;
  let persistenceWarning: string | null = null;
  let persistenceSchema: "full" | "legacy" | "unavailable" = "unavailable";

  if (!adminPreview) {
    if (!isSupabaseConfigured()) {
      // OCR and analysis succeeded. Keep the result usable and explicitly say
      // that it was not saved or counted instead of hiding it from the user.
      persistenceWarning = "Predictions are ready, but history saving is unavailable in this environment. No prediction credits were counted.";
      log("persistence_skipped", { reason: "supabase_not_configured" });
    } else {
      try {
        const sb = await getRequestSupabase(body?.userToken);
        const { count: used, error: countError } = await sb
          .from("predictions")
          .select("id", { count: "exact", head: true })
          .eq("user_id", String(user.id))
          .gte("created_at", startOfTodayISO());
        if (countError) throw countError;
        usedToday = used ?? 0;
        if (limit !== null && usedToday + count > limit) {
          return NextResponse.json(
            {
              error: `You have ${Math.max(0, limit - usedToday)} of ${limit} predictions remaining today on your ${plan!.name} plan, but this screenshot has ${count} verified matches. Come back tomorrow or upgrade your plan.`,
              code: "PLAN_LIMIT",
              detected: count,
              limit,
              remaining: Math.max(0, limit - usedToday),
              requestId,
            },
            { status: 403 }
          );
        }

        const rows = verified.map((f, i) => {
          const a = analyses[i];
          const pickLabel = a.predicted === "1" ? `${f.homeName} (Home)` : a.predicted === "X" ? "Draw" : `${f.awayName} (Away)`;
          return {
            user_id: String(user.id),
            league: f.league || parsed.league || null,
            home_team: f.homeName,
            away_team: f.awayName,
            pick: pickLabel,
            win_rate: a.confidence,
            source_screenshot: body?.screenshotName ? String(body.screenshotName) : null,
            home_prob: a.model.home,
            draw_prob: a.model.draw,
            away_prob: a.model.away,
            confidence: a.confidence,
            data_quality: a.dataQuality,
            model_json: JSON.stringify(a),
          };
        });

        persistenceSchema = await insertPredictionWithSchemaFallback(sb, rows);
        persisted = true;
        if (persisted) usedToday = (usedToday ?? 0) + count;
      } catch (err) {
        persistenceWarning = "Predictions are ready, but they could not be saved to history right now. No prediction credits were counted.";
        log("persist_error", { error: err instanceof Error ? err.message : String(err) });
      }
    }
  }

  if (persistenceWarning && usedToday === 0) {
    // Null distinguishes "unknown/not counted" from a genuine zero used today.
    usedToday = null;
  }
  log("done", { count, usedToday, persisted, persistenceSchema, ms: Date.now() - started });

  return NextResponse.json({
    ok: true,
    requestId,
    preview: adminPreview,
    persisted,
    persistenceSchema,
    warning: persistenceWarning,
    saved: adminPreview ? 0 : count,
    usedToday: persistenceWarning && !persisted ? null : usedToday,
    limit,
    plan: adminPreview ? "Admin test mode" : plan!.name,
    league: parsed.league,
    matches: verified.map((f, i) => ({
      league: f.league || parsed.league || "VIRTUAL LEAGUE",
      datetime: f.datetime,
      homeCode: f.homeCode,
      awayCode: f.awayCode,
      homeName: f.homeName,
      awayName: f.awayName,
      analysis: analyses[i],
    })),
    unverified: unverified.map((f) => ({
      homeCode: f.homeCode,
      awayCode: f.awayCode,
      homeName: f.homeName,
      awayName: f.awayName,
      issues: f.issues,
    })),
    issues: parsed.issues,
    stages: [
      "Uploading Screenshot",
      "Scanning Image",
      "Detecting Match Rows",
      "Extracting Team Names",
      "Extracting Betting Odds",
      "Verifying Information",
      "Analyzing Football Statistics",
      "Generating Predictions",
      "Results Ready",
    ],
  });
}
