import { NextResponse } from "next/server";
import { getCurrentUser, getUserByToken } from "@/lib/auth";

export const runtime = "nodejs";

/** Returns the signed-in user (cookie or ?t= token), or { user: null }. */
export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const t = url.searchParams.get("t");
    const user = (await getCurrentUser()) || (await getUserByToken(t));
    if (!user) return NextResponse.json({ user: null });

    return NextResponse.json({
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        phone: user.phone,
        country: user.country,
        countryFlag: user.countryFlag,
        currency: user.currency,
        registrationStatus: user.registrationStatus,
        activePlan: user.activePlan,
        planStatus: user.planStatus,
        pendingPlan: user.pendingPlan,
        avatarInitial: user.avatarInitial,
        isAdmin: user.isAdmin,
        isAgent: user.isAgent,
      },
    });
  } catch {
    return NextResponse.json({ user: null });
  }
}
