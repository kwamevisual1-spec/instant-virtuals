import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { getCurrentUser, getUserByToken } from "@/lib/auth";
import { getPlan, RECIPIENT } from "@/lib/plans";
import { isSupabaseConfigured, getRequestSupabase, createServerSupabase } from "@/lib/supabase";
import { decryptSignup } from "@/lib/signupToken";
import { fetchSupabaseProfile } from "@/lib/supabaseData";
import { verifyUserToken } from "@/lib/token";
import { getUserById } from "@/lib/auth";
import { isMissingSchemaError, SETUP_HINT } from "@/lib/supabaseErrors";
import { agentService } from "@/lib/agentService";
import { firstReferral } from "@/lib/referrals";
import { REGISTRATION_FEE } from "@/lib/plans";

export const runtime = "nodejs";

/* --------------------------------- GET ---------------------------------- */

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (user.isAgent) return NextResponse.json({ error: "Agents cannot make customer payments." }, { status: 403 });

  if (isSupabaseConfigured()) {
    const sb = await getRequestSupabase();
    const { data } = await sb
      .from("payments")
      .select("*")
      .eq("user_id", String(user.id))
      .order("created_at", { ascending: false });
    return NextResponse.json({ payments: data || [] });
  }

  const rows = await db
    .select()
    .from(payments)
    .where(eq(payments.userId, Number(user.id)))
    .orderBy(desc(payments.id));
  return NextResponse.json({ payments: rows });
}

/* --------------------------------- POST --------------------------------- */

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (isSupabaseConfigured()) return await postSupabase(body);
    return await postLocal(body);
  } catch (err) {
    console.error("Payment submission error", err);
    return NextResponse.json(
      { error: "Server error while submitting payment." },
      { status: 500 }
    );
  }
}

/* ----------------------------- Supabase mode ---------------------------- */

/**
 * Find the signed-in user, or (registration only) create the account NOW from
 * the encrypted sign-up ticket. This is the first moment anything is saved
 * to Supabase auth for a new customer.
 */
async function resolveOrCreateUser(body: any) {
  const sb = await getRequestSupabase(body?.userToken);
  const { data: auth } = await sb.auth.getUser();
  if (auth.user) return { sb, user: auth.user };

  if (body?.paymentType === "registration" && body?.signupToken) {
    const pending = decryptSignup(body.signupToken);
    if (!pending) {
      return NextResponse.json(
        {
          error:
            "Your registration session expired. Please go back and create your account again.",
        },
        { status: 400 }
      );
    }

    const server = await createServerSupabase();
    const { data, error } = await server.auth.signUp({
      email: pending.email,
      password: pending.password,
      options: {
        data: {
          full_name: pending.fullName,
          phone: pending.phone,
          country: pending.country,
          country_flag: pending.countryFlag,
          currency: pending.currency,
        },
      },
    });

    const alreadyExists =
      (error && /already|exists/i.test(error.message)) ||
      (data?.user &&
        Array.isArray(data.user.identities) &&
        data.user.identities.length === 0);

    if (alreadyExists) {
      // A leftover/unpaid account with the same login (e.g. earlier test or
      // an interrupted attempt). If the password matches, reuse it; if it
      // already paid, tell them to sign in.
      const si = await server.auth.signInWithPassword({
        email: pending.email,
        password: pending.password,
      });
      if (si.error || !si.data.session || !si.data.user) {
        return NextResponse.json(
          {
            error:
              "An account with this email already exists. Please sign in, or use \"Forgot password?\".",
          },
          { status: 409 }
        );
      }
      const { data: prior } = await server
        .from("payments")
        .select("status")
        .eq("user_id", si.data.user.id)
        .eq("payment_type", "registration")
        .in("status", ["pending", "approved"])
        .limit(1);
      if (prior && prior.length > 0) {
        await server.auth.signOut();
        return NextResponse.json(
          { error: "This email is already registered. Please sign in instead." },
          { status: 409 }
        );
      }
      return { sb: server, user: si.data.user };
    }

    if (error) {
      return NextResponse.json(
        { error: /rate limit|too many/i.test(error.message) ? "Too many attempts. Please wait a minute and try again." : error.message },
        { status: 400 }
      );
    }
    if (!data.session || !data.user) {
      return NextResponse.json(
        {
          error:
            "Email confirmation is still switched on in Supabase. Turn OFF \"Confirm email\" (Authentication → Sign In / Providers → Email) and try again.",
        },
        { status: 400 }
      );
    }
    return { sb: server, user: data.user };
  }

  return NextResponse.json(
    { error: "Your session expired. Please sign in again." },
    { status: 401 }
  );
}

async function postSupabase(body: any) {
  const {
    paymentType,
    planCode,
    amount,
    transactionReference,
    screenshotName,
    screenshotData,
  } = body || {};

  // Validate everything BEFORE any account is created.
  if (!screenshotName || !screenshotData) {
    return NextResponse.json(
      { error: "Payment screenshot is required." },
      { status: 400 }
    );
  }
  if (paymentType !== "registration" && paymentType !== "plan") {
    return NextResponse.json({ error: "Invalid payment type." }, { status: 400 });
  }
  const plan = paymentType === "plan" ? getPlan(planCode) : undefined;
  if (paymentType === "plan" && !plan) {
    return NextResponse.json({ error: "Invalid plan selected." }, { status: 400 });
  }
  {
    const r = String(screenshotData);
    const c = r.indexOf(",");
    const h = c > 5 ? r.slice(5, c) : "";
    if (!(h.startsWith("image/jpeg") || h.startsWith("image/png")) || c < 0) {
      return NextResponse.json(
        { error: "Invalid screenshot. Please upload a JPG or PNG image." },
        { status: 400 }
      );
    }
  }

  const pendingSignup = body?.signupToken ? decryptSignup(body.signupToken) : null;
  const referralCode = pendingSignup?.referralCode || (await firstReferral());
  const resolved = await resolveOrCreateUser(body);
  if (resolved instanceof NextResponse) return resolved;
  const { sb, user } = resolved;
  if ((await fetchSupabaseProfile(sb, user.id, user.email || ""))?.isAgent) return NextResponse.json({ error: "Agents cannot make customer payments." }, { status: 403 });

  if (paymentType === "registration" && referralCode) {
    const claimClient = process.env.SUPABASE_SERVICE_ROLE_KEY ? agentService() : sb;
    const { error: claimError } = await claimClient.rpc("claim_referral", { p_customer: user.id, p_code: referralCode });
    if (claimError) {
      console.error("Referral claim failed", claimError);
      return NextResponse.json({ error: "Could not attach your referral. Please contact support." }, { status: 503 });
    }
  }
  const profile = await fetchSupabaseProfile(sb, user.id, user.email || "");
  if (!profile) {
    return NextResponse.json(
      {
        error:
          "Profile not found. Please run supabase/schema.sql in the Supabase SQL Editor.",
      },
      { status: 500 }
    );
  }

  // Decode the base64 data URL and store the image in Supabase Storage
  const raw = String(screenshotData);
  const comma = raw.indexOf(",");
  const header = comma > 5 ? raw.slice(5, comma) : "";
  const b64 = comma > 0 ? raw.slice(comma + 1) : "";
  const kind = header.startsWith("image/jpeg") ? "jpeg" : header.startsWith("image/png") ? "png" : "";
  if (!kind || !b64) {
    return NextResponse.json(
      { error: "Invalid screenshot. Please upload a JPG or PNG image." },
      { status: 400 }
    );
  }
  const buffer = Buffer.from(b64, "base64");
  const safeName = String(screenshotName).replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  const objectPath = `${user.id}/${Date.now()}-${safeName}`;

  const { error: upErr } = await sb.storage
    .from("payment-proofs")
    .upload(objectPath, buffer, { contentType: `image/${kind}`, upsert: false });
  if (upErr) {
    console.error("Storage upload error", upErr);
    return NextResponse.json(
      {
        error: isMissingSchemaError(upErr)
          ? SETUP_HINT
          : "Could not save your screenshot. Please try again.",
      },
      { status: 500 }
    );
  }

  if (paymentType === "registration") {
    const { data: existing } = await sb
      .from("payments")
      .select("status")
      .eq("user_id", user.id)
      .eq("payment_type", "registration")
      .order("created_at", { ascending: false })
      .limit(1);
    if (existing?.[0]?.status === "approved") {
      return NextResponse.json(
        { error: "Registration already approved." },
        { status: 400 }
      );
    }

    const { error: insErr } = await sb.from("payments").insert({
      user_id: user.id,
      payment_type: "registration",
      amount: REGISTRATION_FEE,
      network: RECIPIENT.network,
      recipient_number: RECIPIENT.number,
      recipient_name: RECIPIENT.name,
      referred_agent_id: (await sb.from("profiles").select("referred_agent_id").eq("id", user.id).single()).data?.referred_agent_id || null,
      currency: profile.currency,
      transaction_reference: transactionReference ? String(transactionReference) : null,
      screenshot_name: String(screenshotName),
      screenshot_url: objectPath,
      status: "pending",
    });
    if (insErr) {
      console.error("Registration payment insert error", insErr);
      return NextResponse.json(
        {
          error: isMissingSchemaError(insErr)
            ? SETUP_HINT
            : "Could not save your payment. Please try again.",
        },
        { status: 500 }
      );
    }

    // Sign out; they sign in again once the admin approves.
    await sb.auth.signOut();
    return NextResponse.json({
      ok: true,
      shouldSignOut: true,
      message: "Registration payment submitted. Please sign in once approved.",
    });
  }

  // Plan payment
  const { error: planInsErr } = await sb.from("payments").insert({
    user_id: user.id,
    payment_type: "plan",
    plan_code: plan!.code,
    plan_name: plan!.name,
    amount: plan!.amount,
    network: RECIPIENT.network,
    recipient_number: RECIPIENT.number,
    recipient_name: RECIPIENT.name,
    referred_agent_id: (await sb.from("profiles").select("referred_agent_id").eq("id", user.id).single()).data?.referred_agent_id || null,
    currency: profile.currency,
    transaction_reference: transactionReference ? String(transactionReference) : null,
    screenshot_name: String(screenshotName),
    screenshot_url: objectPath,
    status: "pending",
  });
  if (planInsErr) {
    console.error("Plan payment insert error", planInsErr);
    return NextResponse.json(
      {
        error: isMissingSchemaError(planInsErr)
          ? SETUP_HINT
          : "Could not save your payment. Please try again.",
      },
      { status: 500 }
    );
  }

  const { error: rpcErr } = await sb.rpc("request_plan", { p_plan: plan!.code });
  if (rpcErr) console.error("request_plan error", rpcErr);

  return NextResponse.json({
    ok: true,
    shouldSignOut: false,
    message: "Plan payment submitted. Awaiting admin approval.",
  });
}

/* ------------------------------ Local mode ------------------------------ */

async function postLocal(body: any) {
  let user = await getCurrentUser();
  if (!user) {
    const tokenUserId = verifyUserToken(body?.userToken);
    if (tokenUserId) user = await getUserById(tokenUserId);
  }
  if (!user) {
    return NextResponse.json(
      { error: "Your session expired. Please sign in again." },
      { status: 401 }
    );
  }

  const uid = Number(user.id);
  const {
    paymentType,
    planCode,
    amount,
    currency,
    transactionReference,
    screenshotName,
    screenshotData,
  } = body || {};

  if (!screenshotName || !screenshotData) {
    return NextResponse.json(
      { error: "Payment screenshot is required." },
      { status: 400 }
    );
  }

  if (paymentType === "registration") {
    const existingApproved = await db
      .select({ id: payments.id })
      .from(payments)
      .where(
        and(
          eq(payments.userId, uid),
          eq(payments.paymentType, "registration"),
          eq(payments.status, "approved")
        )
      )
      .limit(1);
    if (existingApproved.length > 0) {
      return NextResponse.json(
        { error: "Registration already approved." },
        { status: 400 }
      );
    }

    await db.insert(payments).values({
      userId: uid,
      paymentType: "registration",
      amount: REGISTRATION_FEE,
      network: RECIPIENT.network,
      recipientNumber: RECIPIENT.number,
      recipientName: RECIPIENT.name,
      currency: String(currency || user.currency || "GHS"),
      transactionReference: transactionReference ? String(transactionReference) : null,
      screenshotName: String(screenshotName),
      screenshotData: String(screenshotData),
      status: "pending",
    });

    return NextResponse.json({
      ok: true,
      shouldSignOut: true,
      message: "Registration payment submitted. Please sign in once approved.",
    });
  }

  if (paymentType === "plan") {
    const plan = getPlan(planCode);
    if (!plan) {
      return NextResponse.json({ error: "Invalid plan selected." }, { status: 400 });
    }

    await db.insert(payments).values({
      userId: uid,
      paymentType: "plan",
      planCode: plan.code,
      planName: plan.name,
      amount: plan.amount,
      network: RECIPIENT.network,
      recipientNumber: RECIPIENT.number,
      recipientName: RECIPIENT.name,
      currency: String(currency || user.currency || "GHS"),
      transactionReference: transactionReference ? String(transactionReference) : null,
      screenshotName: String(screenshotName),
      screenshotData: String(screenshotData),
      status: "pending",
    });

    await db
      .update(users)
      .set({ pendingPlan: plan.code, planStatus: "pending" })
      .where(eq(users.id, uid));

    return NextResponse.json({
      ok: true,
      shouldSignOut: false,
      message: "Plan payment submitted. Awaiting admin approval.",
    });
  }

  return NextResponse.json({ error: "Invalid payment type." }, { status: 400 });
}
