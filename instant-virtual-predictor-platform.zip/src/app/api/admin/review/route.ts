import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { isAdminSession, checkAdminSupabase } from "@/lib/adminAuth";
import { isSupabaseConfigured } from "@/lib/supabase";
import { isMissingSchemaError, SETUP_HINT } from "@/lib/supabaseErrors";

export const runtime = "nodejs";

export async function POST(req: Request) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  // Supabase mode: get an admin-authenticated client (cookie OR token in the
  // request body / Authorization header).
  const check = isSupabaseConfigured() ? await checkAdminSupabase(body?.accessToken) : null;
  const adminSb = check?.client ?? null;
  if (isSupabaseConfigured() ? !adminSb : !(await isAdminSession())) {
    const reason = check?.reason ?? "no_session";
    return NextResponse.json(
      {
        error:
          reason === "not_admin"
            ? "This account is not an admin. Sign in with the admin email."
            : "Your admin session could not be verified.",
        reason,
      },
      { status: 401 }
    );
  }
  try {
    const { paymentId, action, kind, planCode } = body || {};
    if (!paymentId || !action || !kind) {
      return NextResponse.json(
        { error: "Missing parameters" },
        { status: 400 }
      );
    }
    if (!["approve", "reject", "reverse"].includes(action)) {
      return NextResponse.json({ error: "Invalid action" }, { status: 400 });
    }
    if (!["registration", "plan"].includes(kind)) {
      return NextResponse.json(
        { error: "Invalid payment kind" },
        { status: 400 }
      );
    }
    const approve = action === "approve";

    /* ------------------------------ Supabase ------------------------------ */
    if (isSupabaseConfigured()) {
      const svc = adminSb!; // admin-authenticated client; admin RLS policies apply
      const { data: pay, error: payErr } = await svc
        .from("payments")
        .select("*")
        .eq("id", Number(paymentId))
        .maybeSingle();
      if (payErr) {
        return NextResponse.json(
          { error: isMissingSchemaError(payErr) ? SETUP_HINT : payErr.message },
          { status: 500 }
        );
      }
      if (!pay) {
        return NextResponse.json({ error: "Payment not found" }, { status: 404 });
      }

      if (pay.payment_type !== kind) {
        return NextResponse.json({ error: "Payment type does not match the request." }, { status: 400 });
      }
      // Single database transaction: payment status, customer access,
      // rate-snapshotted commission (UNIQUE payment_id), and audit log.
      const { data: result, error: reviewError } = await svc.rpc("review_agent_payment", {
        p_payment_id: Number(pay.id),
        p_action: action,
      });
      if (reviewError) {
        // Before the agent migration is installed, preserve the existing
        // payment-verification workflow for existing customers.
        if (reviewError.code === "PGRST202") {
          if (action === "reverse") return NextResponse.json({ error: "Run supabase/agents.sql before reversing payments." }, { status: 503 });
          const { data: changed, error: updateError } = await svc.from("payments")
            .update({ status: approve ? "approved" : "rejected" })
            .eq("id", pay.id).eq("status", "pending").select("id");
          if (updateError || !changed?.length) return NextResponse.json({ error: updateError?.message || "Payment already reviewed" }, { status: 409 });
          const patch = kind === "registration"
            ? { registration_status: approve ? "approved" : "rejected" }
            : approve
              ? { active_plan: pay.plan_code, plan_status: "active", pending_plan: null }
              : { pending_plan: null, plan_status: "none" };
          const { error: profileError } = await svc.from("profiles").update(patch).eq("id", pay.user_id);
          if (profileError) return NextResponse.json({ error: profileError.message }, { status: 500 });
          return NextResponse.json({ ok: true, legacy: true });
        }
        return NextResponse.json({ error: reviewError.message }, { status: 400 });
      }
      return NextResponse.json({ ok: true, result });
    }

    /* ------------------------------- Local -------------------------------- */
    if (action === "reverse") return NextResponse.json({ error: "Reversal requires the Supabase agent migration." }, { status: 503 });
    const [payment] = await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.id, Number(paymentId)),
          eq(payments.paymentType, kind as "registration" | "plan")
        )
      )
      .limit(1);

    if (!payment) {
      return NextResponse.json({ error: "Payment not found" }, { status: 404 });
    }

    await db
      .update(payments)
      .set({ status: approve ? "approved" : "rejected" })
      .where(eq(payments.id, payment.id));

    if (kind === "registration") {
      await db
        .update(users)
        .set({ registrationStatus: approve ? "approved" : "rejected" })
        .where(eq(users.id, payment.userId));
    } else if (kind === "plan") {
      const code = planCode || payment.planCode;
      if (approve && code) {
        await db
          .update(users)
          .set({ activePlan: code, planStatus: "active", pendingPlan: null })
          .where(eq(users.id, payment.userId));
      } else {
        await db
          .update(users)
          .set({ pendingPlan: null, planStatus: "none" })
          .where(eq(users.id, payment.userId));
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Admin review error", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
