import { NextResponse } from "next/server";
import { getAdminSupabase } from "@/lib/adminAuth";
import { publicSiteOrigin } from "@/lib/siteOrigin";
import { createAgentOp, listAgentsOp, updateAgentOp } from "@/lib/agentAdminOps";

export const runtime = "nodejs";
const noStore = { "Cache-Control": "private, no-store" };

export async function GET(req: Request) {
  const token = new URL(req.url).searchParams.get("t") || undefined;
  const sb = await getAdminSupabase(token);
  if (!sb) return NextResponse.json({ error: "Admin only" }, { status: 403, headers: noStore });
  const { status, body } = await listAgentsOp(sb, publicSiteOrigin(req.headers, req.url));
  return NextResponse.json(body, { status, headers: noStore });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const sb = await getAdminSupabase(body.accessToken);
  if (!sb) return NextResponse.json({ error: "Admin only" }, { status: 403, headers: noStore });
  const result = await createAgentOp(sb, body, publicSiteOrigin(req.headers, req.url));
  return NextResponse.json(result.body, { status: result.status, headers: noStore });
}

export async function PATCH(req: Request) {
  const body = await req.json().catch(() => ({}));
  const sb = await getAdminSupabase(body.accessToken);
  if (!sb) return NextResponse.json({ error: "Admin only" }, { status: 403, headers: noStore });
  const result = await updateAgentOp(sb, body);
  return NextResponse.json(result.body, { status: result.status, headers: noStore });
}
