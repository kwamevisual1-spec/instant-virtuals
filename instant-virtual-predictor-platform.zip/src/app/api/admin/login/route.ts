import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { cookieOptions } from "@/lib/auth";
import { signAdminToken } from "@/lib/token";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const { password } = await req.json().catch(() => ({ password: "" }));
  const expected = process.env.ADMIN_PASSWORD || "admin123";
  if (String(password) !== expected) {
    return NextResponse.json({ error: "Invalid password" }, { status: 401 });
  }
  const cookieStore = await cookies();
  cookieStore.set("vp_admin", "1", await cookieOptions(60 * 60 * 4));
  const token = signAdminToken();
  return NextResponse.json({ ok: true, token });
}
